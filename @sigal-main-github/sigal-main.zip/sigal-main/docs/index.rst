.. include:: ../README.rst

Documentation
-------------

.. toctree::
   :maxdepth: 2

   installation
   getting_started
   configuration
   album_information
   image_information
   themes
   plugins
   faq
   contribute
   license
   changelog
