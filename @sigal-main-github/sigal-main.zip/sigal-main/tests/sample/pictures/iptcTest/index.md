Title: iptc test gallery

## This is used by test_image.py and test_gallery.py to validate iptc handling
