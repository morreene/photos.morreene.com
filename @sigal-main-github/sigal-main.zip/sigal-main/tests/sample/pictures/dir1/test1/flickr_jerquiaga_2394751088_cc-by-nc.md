Title: WÎth spécial chÆracters

This is a funny description of this image
