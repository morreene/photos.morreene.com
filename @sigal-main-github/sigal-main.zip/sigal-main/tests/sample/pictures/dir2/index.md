Title: Another example gallery with a very long name
Thumbnail: m57_the_ring_nebula-587px.jpg


This is an [example link](http://example.com/ "With a Title").


1. A list item.
2. Another item in the list.

### Image sources

- *Hubble Interacting Galaxy NGC 5257* : By NASA, ESA, the Hubble Heritage
  (STScI/AURA)-ESA/Hubble Collaboration, and A. Evans (University of Virginia,
  Charlottesville/NRAO/Stony Brook University) [Public domain], <a
  href="https://commons.wikimedia.org/wiki/File:Hubble_Interacting_Galaxy_NGC_5257_(2008-04-24).jpg">
  from Wikimedia Commons</a>

- *Hubble ultra deep field.jpg* : By NASA and the European Space Agency.
  [Public domain], <a
  href="https://commons.wikimedia.org/wiki/File%3AHubble_ultra_deep_field.jpg">
  from Wikimedia Commons</a>

- *m57_the_ring_nebula-587px.jpg* : By The Hubble Heritage Team
  (AURA/STScI/NASA) [Public domain], <a
  href="https://commons.wikimedia.org/wiki/File%3AM57_The_Ring_Nebula.JPG">
  from Wikimedia Commons</a>

- *KeckObservatory20071020.jpg* : By SiOwl [CC BY 3.0] <a
  href="https://commons.wikimedia.org/wiki/File:KeckObservatory20071020.jpg">
  from Wikimedia Commons</a>
